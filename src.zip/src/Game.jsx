import Board from './Board';
import './App.css';

function Game() {
    return (
        <><div>
            <h1>This is Tic Tac Toe</h1>
        </div>
            <div className="game">
                <div className="game-board">
                    <Board />
                </div>
                <div className="game-info">
                    <div>{/* status */}</div>
                    <ol>{/* TODO */}</ol>
                </div>
            </div></>
    );
}
export default Game;